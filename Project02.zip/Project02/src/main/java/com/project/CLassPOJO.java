package com.project;

public class CLassPOJO {

	private    int clid;
	private    String clname;
	private    String clsubject;
	public int getClid() {
		return clid;
	}
	public void setClid(int clid) {
		this.clid = clid;
	}
	public String getClname() {
		return clname;
	}
	public void setClname(String clname) {
		this.clname = clname;
	}
	public String getClsubject() {
		return clsubject;
	}
	public void setClsubject(String clsubject) {
		this.clsubject = clsubject;
	}
	public String getClteacher() {
		return clteacher;
	}
	public void setClteacher(String clteacher) {
		this.clteacher = clteacher;
	}
	public String getClstudent() {
		return clstudent;
	}
	public void setClstudent(String clstudent) {
		this.clstudent = clstudent;
	}
	private    String clteacher;
	private    String clstudent;
}
