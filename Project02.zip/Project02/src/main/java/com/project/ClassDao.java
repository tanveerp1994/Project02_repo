package com.project;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import com.project.CLassPOJO;
import com.project.DbConn;

public class ClassDao {
	
	public int insertstd(CLassPOJO st) throws ClassNotFoundException, SQLException {
        Connection con=DbConn.getConn();
        String sql="insert into Class values(?,?,?,?,?)";
        PreparedStatement ps=con.prepareStatement(sql);
        ps.setInt(1, st.getClid());
        ps.setString(2,st.getClname());
        ps.setString(3,st.getClsubject());
        ps.setString(4,st.getClteacher());
        ps.setString(5,st.getClstudent());
        
        
        return ps.executeUpdate();
    }
    
    
    public boolean updatestd(CLassPOJO st)throws ClassNotFoundException, SQLException {
    	//check
    	Connection con=DbConn.getConn();
    	String sql="UPDATE Class SET clname=?,clsubject=?,clteacher=?,clstudent=?";
    	sql += "WHERE clid=?";
    	PreparedStatement ps=con.prepareStatement(sql);
    	
  	    	
        ps.setString(1,st.getClname());
        ps.setString(2,st.getClsubject());
        ps.setString(3,st.getClteacher());
        ps.setString(4,st.getClstudent());
        
        ps.setInt(5, st.getClid());
    	boolean rowUpdate=ps.executeUpdate() > 0;
    	ps.close();
    	
    	
    	return rowUpdate;      
    }
    
    
    public boolean deletestd(CLassPOJO st)throws ClassNotFoundException, SQLException {
    	Connection con=DbConn.getConn();
    	String sql=" DELETE FROM Class WHERE clid=?";
    	PreparedStatement ps=con.prepareStatement(sql);
    	ps.setInt(1, st.getClid());
    	
    	boolean rowUpdate=ps.executeUpdate() > 0;
    	ps.close();
    	return rowUpdate;
    }
    
    
    public List<CLassPOJO> display() throws ClassNotFoundException, SQLException{
        Connection con=DbConn.getConn();
        List<CLassPOJO> list=new ArrayList<CLassPOJO>();
        String sql="select * from Class";
        PreparedStatement ps=con.prepareStatement(sql);
        ResultSet rs=ps.executeQuery();
        while(rs.next()) {
            CLassPOJO pojo=new CLassPOJO();
            pojo.setClid(rs.getInt(1));
            pojo.setClname(rs.getString(2));
            pojo.setClsubject(rs.getString(3));
            pojo.setClteacher(rs.getString(4));
            pojo.setClstudent(rs.getString(5));
            list.add(pojo);
        }
        
        return list;
        
    }

}
