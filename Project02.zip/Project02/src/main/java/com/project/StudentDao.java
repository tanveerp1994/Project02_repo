package com.project;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;


import com.project.StudentPOJO;
import com.project.DbConn;

public class StudentDao {

		
		public int insertstd(StudentPOJO st) throws ClassNotFoundException, SQLException {
	        Connection con=DbConn.getConn();
	        String sql="insert into Student values(?,?,?)";
	        PreparedStatement ps=con.prepareStatement(sql);
	        ps.setInt(1, st.getStid());
	        ps.setString(2,st.getStname());
	        ps.setString(3,st.getStclass());
	        
	        return ps.executeUpdate();
	    }
	    
	    
	    public boolean updatestd(StudentPOJO st)throws ClassNotFoundException, SQLException {
	    	//check
	    	Connection con=DbConn.getConn();
	    	String sql="UPDATE Student SET stname=?,stclass=?";
	    	sql += "WHERE stid=?";
	    	PreparedStatement ps=con.prepareStatement(sql);
	    	
	  	    	
	        ps.setString(1,st.getStname());
	        ps.setString(2,st.getStclass());
	        ps.setInt(3, st.getStid());
	    	boolean rowUpdate=ps.executeUpdate() > 0;
	    	ps.close();
	    	
	    	
	    	return rowUpdate;      
	    }
	    
	    
	    public boolean deletestd(StudentPOJO st)throws ClassNotFoundException, SQLException {
	    	Connection con=DbConn.getConn();
	    	String sql=" DELETE FROM Student WHERE stid=?";
	    	PreparedStatement ps=con.prepareStatement(sql);
	    	ps.setInt(1, st.getStid());
	    	
	    	boolean rowUpdate=ps.executeUpdate() > 0;
	    	ps.close();
	    	return rowUpdate;
	    }
	    
	    
	    public List<StudentPOJO> display() throws ClassNotFoundException, SQLException{
	        Connection con=DbConn.getConn();
	        List<StudentPOJO> list=new ArrayList<StudentPOJO>();
	        String sql="select * from Student";
	        PreparedStatement ps=con.prepareStatement(sql);
	        ResultSet rs=ps.executeQuery();
	        while(rs.next()) {
	            StudentPOJO pojo=new StudentPOJO();
	            pojo.setStid(rs.getInt(1));
	            pojo.setStname(rs.getString(2));
	            pojo.setStclass(rs.getString(3));
	            list.add(pojo);
	        }
	        
	        return list;
	        
	    }

		


}
