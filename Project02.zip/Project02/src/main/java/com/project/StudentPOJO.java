package com.project;

public class StudentPOJO {
	
	private    int stid;
	private    String stname;
	private    String stclass;
	
	public String getStclass() {
		return stclass;
	}
	public void setStclass(String stclass) {
		this.stclass = stclass;
	}
	public int getStid() {
		return stid;
	}
	public void setStid(int stid) {
		this.stid = stid;
	}
	public String getStname() {
		return stname;
	}
	public void setStname(String stname) {
		this.stname = stname;
	}
	

}
