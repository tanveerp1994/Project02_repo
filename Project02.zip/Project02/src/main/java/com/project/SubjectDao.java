package com.project;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class SubjectDao {
	
	public int insertstd(SubjectPOJO st) throws ClassNotFoundException, SQLException {
        Connection con=DbConn.getConn();
        String sql="insert into Subject02 values(?,?)";
        PreparedStatement ps=con.prepareStatement(sql);
        ps.setInt(1, st.getSid());
        ps.setString(2,st.getSname());
        
        return ps.executeUpdate();
    }
    
    
    public boolean updatestd(SubjectPOJO st)throws ClassNotFoundException, SQLException {
    	//check
    	Connection con=DbConn.getConn();
    	String sql="UPDATE Subject02 SET sname=?";
    	sql += "WHERE sid=?";
    	PreparedStatement ps=con.prepareStatement(sql);
    	
  	    	
        ps.setString(1,st.getSname());
        ps.setInt(2, st.getSid());
    	boolean rowUpdate=ps.executeUpdate() > 0;
    	ps.close();
    	
    	
    	return rowUpdate;      
    }
    
    
    public boolean deletestd(SubjectPOJO st)throws ClassNotFoundException, SQLException {
    	Connection con=DbConn.getConn();
    	String sql=" DELETE FROM Subject02 WHERE sid=?";
    	PreparedStatement ps=con.prepareStatement(sql);
    	ps.setInt(1, st.getSid());
    	
    	boolean rowUpdate=ps.executeUpdate() > 0;
    	ps.close();
    	return rowUpdate;
    }
    
    
    public List<SubjectPOJO> display() throws ClassNotFoundException, SQLException{
        Connection con=DbConn.getConn();
        List<SubjectPOJO> list=new ArrayList<SubjectPOJO>();
        String sql="select * from Subject02";
        PreparedStatement ps=con.prepareStatement(sql);
        ResultSet rs=ps.executeQuery();
        while(rs.next()) {
            SubjectPOJO pojo=new SubjectPOJO();
            pojo.setSid(rs.getInt(1));
            pojo.setSname(rs.getString(2));
            list.add(pojo);
        }
        
        return list;
        
    }


}
