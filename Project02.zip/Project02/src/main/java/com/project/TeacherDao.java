package com.project;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import com.project.TeacherPOJO;
import com.project.DbConn;
public class TeacherDao {
	

	public int insertstd(TeacherPOJO st) throws ClassNotFoundException, SQLException {
        Connection con=DbConn.getConn();
        String sql="insert into Teacher values(?,?,?,?,?)";
        PreparedStatement ps=con.prepareStatement(sql);
        ps.setInt(1, st.getTid());
        ps.setString(2,st.getTname());
        ps.setString(3,st.getTaddress());
        ps.setString(4,st.getTphone());
        ps.setString(5,st.getTdesignation());
        
        
        return ps.executeUpdate();
    }
    
    
    public boolean updatestd(TeacherPOJO st)throws ClassNotFoundException, SQLException {
    	//check
    	Connection con=DbConn.getConn();
    	String sql="UPDATE Teacher SET Tname=?,Taddress=?,Tphone=?,Tdesignation=?";
    	sql += "WHERE Tid=?";
    	PreparedStatement ps=con.prepareStatement(sql);
    	
  	    	
        ps.setString(1,st.getTname());
        ps.setString(2,st.getTaddress());
        ps.setString(3,st.getTphone());
        ps.setString(4,st.getTdesignation());
        
        ps.setInt(5, st.getTid());
    	boolean rowUpdate=ps.executeUpdate() > 0;
    	ps.close();
    	
    	
    	return rowUpdate;      
    }
    
    
    public boolean deletestd(TeacherPOJO st)throws ClassNotFoundException, SQLException {
    	Connection con=DbConn.getConn();
    	String sql=" DELETE FROM Teacher WHERE Tid=?";
    	PreparedStatement ps=con.prepareStatement(sql);
    	ps.setInt(1, st.getTid());
    	
    	boolean rowUpdate=ps.executeUpdate() > 0;
    	ps.close();
    	return rowUpdate;
    }
    
    
    public List<TeacherPOJO> display() throws ClassNotFoundException, SQLException{
        Connection con=DbConn.getConn();
        List<TeacherPOJO> list=new ArrayList<TeacherPOJO>();
        String sql="select * from Teacher";
        PreparedStatement ps=con.prepareStatement(sql);
        ResultSet rs=ps.executeQuery();
        while(rs.next()) {
            TeacherPOJO pojo=new TeacherPOJO();
            pojo.setTid(rs.getInt(1));
            pojo.setTname(rs.getString(2));
            pojo.setTaddress(rs.getString(3));
            pojo.setTphone(rs.getString(4));
            pojo.setTdesignation(rs.getString(5));
            list.add(pojo);
        }
        
        return list;
        
    }

	

}
