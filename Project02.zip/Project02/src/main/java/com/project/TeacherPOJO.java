package com.project;

public class TeacherPOJO {
	
	private    int Tid;
	private    String Tname;
	private    String Taddress;
	private    String Tphone;
	private    String Tdesignation;
	public int getTid() {
		return Tid;
	}
	public void setTid(int tid) {
		Tid = tid;
	}
	public String getTname() {
		return Tname;
	}
	public void setTname(String tname) {
		Tname = tname;
	}
	public String getTaddress() {
		return Taddress;
	}
	public void setTaddress(String taddress) {
		Taddress = taddress;
	}
	public String getTphone() {
		return Tphone;
	}
	public void setTphone(String tphone) {
		Tphone = tphone;
	}
	public String getTdesignation() {
		return Tdesignation;
	}
	public void setTdesignation(String tdesignation) {
		Tdesignation = tdesignation;
	}

}
